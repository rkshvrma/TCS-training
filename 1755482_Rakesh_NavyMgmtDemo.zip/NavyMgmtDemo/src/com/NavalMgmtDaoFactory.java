package com;

public class NavalMgmtDaoFactory {

}
