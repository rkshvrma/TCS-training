package com;

public class IncorrectDataException extends Exception {

	public IncorrectDataException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
