package com.exceptions;

public class BookIdDoesNotExistException extends Exception {

	public BookIdDoesNotExistException(String message) {
		super(message);
	}

}
