package com.exception;

public class BookExistException extends Exception {

	public BookExistException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
