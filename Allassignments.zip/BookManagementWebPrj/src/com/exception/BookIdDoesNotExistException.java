package com.exception;

public class BookIdDoesNotExistException extends Exception {

	public BookIdDoesNotExistException(String message) {
		super(message);
	}

}
