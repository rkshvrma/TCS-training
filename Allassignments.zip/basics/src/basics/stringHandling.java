package basics;

public class stringHandling {
	
	//StringBuffer str = "rakes";

}
