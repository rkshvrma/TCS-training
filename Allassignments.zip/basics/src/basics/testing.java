package basics;

public class testing {
public static void main(String[] args) {
	System.out.println("   ");
}
}
