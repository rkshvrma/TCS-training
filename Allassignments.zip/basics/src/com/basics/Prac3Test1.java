package com.basics;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Prac3Test1 {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
