package com.basics;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Prac3Test {

	@Test
	void test() {
		fail("Not yet implemented");
	}

	
	
}
